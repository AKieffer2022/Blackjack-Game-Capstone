﻿namespace Kieffer.Blackjack
{
    partial class Blackjack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHit = new System.Windows.Forms.Button();
            this.btnStay = new System.Windows.Forms.Button();
            this.btnEndGame = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblPlayerHand = new System.Windows.Forms.Label();
            this.lblDealerHand = new System.Windows.Forms.Label();
            this.lblShowPlayerCards = new System.Windows.Forms.Label();
            this.lblShowDealerCards = new System.Windows.Forms.Label();
            this.lblPlayerScore = new System.Windows.Forms.Label();
            this.lblDealerScore = new System.Windows.Forms.Label();
            this.lblShowPlayerScore = new System.Windows.Forms.Label();
            this.lblShowDealerScore = new System.Windows.Forms.Label();
            this.lblShowWinner = new System.Windows.Forms.Label();
            this.btnPlayAgain = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnHit
            // 
            this.btnHit.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHit.Location = new System.Drawing.Point(267, 355);
            this.btnHit.Name = "btnHit";
            this.btnHit.Size = new System.Drawing.Size(112, 51);
            this.btnHit.TabIndex = 0;
            this.btnHit.Text = "Hit";
            this.btnHit.UseVisualStyleBackColor = true;
            this.btnHit.Click += new System.EventHandler(this.btnHit_Click);
            // 
            // btnStay
            // 
            this.btnStay.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStay.Location = new System.Drawing.Point(388, 355);
            this.btnStay.Name = "btnStay";
            this.btnStay.Size = new System.Drawing.Size(111, 51);
            this.btnStay.TabIndex = 1;
            this.btnStay.Text = "Stay";
            this.btnStay.UseVisualStyleBackColor = true;
            this.btnStay.Click += new System.EventHandler(this.btnStay_Click);
            // 
            // btnEndGame
            // 
            this.btnEndGame.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEndGame.Location = new System.Drawing.Point(324, 427);
            this.btnEndGame.Name = "btnEndGame";
            this.btnEndGame.Size = new System.Drawing.Size(114, 47);
            this.btnEndGame.TabIndex = 2;
            this.btnEndGame.Text = "End Game";
            this.btnEndGame.UseVisualStyleBackColor = true;
            this.btnEndGame.Click += new System.EventHandler(this.btnEndGame_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.Font = new System.Drawing.Font("Monotype Corsiva", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Red;
            this.lblWelcome.Location = new System.Drawing.Point(95, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(594, 74);
            this.lblWelcome.TabIndex = 3;
            this.lblWelcome.Text = "Welcome to BlackJack";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlayerHand
            // 
            this.lblPlayerHand.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerHand.Location = new System.Drawing.Point(30, 231);
            this.lblPlayerHand.Name = "lblPlayerHand";
            this.lblPlayerHand.Size = new System.Drawing.Size(184, 36);
            this.lblPlayerHand.TabIndex = 4;
            this.lblPlayerHand.Text = "Player\'s hand:";
            // 
            // lblDealerHand
            // 
            this.lblDealerHand.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDealerHand.Location = new System.Drawing.Point(505, 238);
            this.lblDealerHand.Name = "lblDealerHand";
            this.lblDealerHand.Size = new System.Drawing.Size(184, 37);
            this.lblDealerHand.TabIndex = 5;
            this.lblDealerHand.Text = "Dealer\'s Hand:";
            // 
            // lblShowPlayerCards
            // 
            this.lblShowPlayerCards.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShowPlayerCards.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShowPlayerCards.Location = new System.Drawing.Point(30, 279);
            this.lblShowPlayerCards.Name = "lblShowPlayerCards";
            this.lblShowPlayerCards.Size = new System.Drawing.Size(231, 461);
            this.lblShowPlayerCards.TabIndex = 6;
            this.lblShowPlayerCards.Text = "Player\'s cards";
            // 
            // lblShowDealerCards
            // 
            this.lblShowDealerCards.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShowDealerCards.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShowDealerCards.Location = new System.Drawing.Point(505, 282);
            this.lblShowDealerCards.Name = "lblShowDealerCards";
            this.lblShowDealerCards.Size = new System.Drawing.Size(231, 458);
            this.lblShowDealerCards.TabIndex = 7;
            this.lblShowDealerCards.Text = "Dealer\'s cards";
            // 
            // lblPlayerScore
            // 
            this.lblPlayerScore.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerScore.Location = new System.Drawing.Point(30, 122);
            this.lblPlayerScore.Name = "lblPlayerScore";
            this.lblPlayerScore.Size = new System.Drawing.Size(184, 48);
            this.lblPlayerScore.TabIndex = 8;
            this.lblPlayerScore.Text = "Player score:";
            // 
            // lblDealerScore
            // 
            this.lblDealerScore.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDealerScore.Location = new System.Drawing.Point(505, 122);
            this.lblDealerScore.Name = "lblDealerScore";
            this.lblDealerScore.Size = new System.Drawing.Size(184, 44);
            this.lblDealerScore.TabIndex = 9;
            this.lblDealerScore.Text = "Dealer\'s Score:";
            // 
            // lblShowPlayerScore
            // 
            this.lblShowPlayerScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShowPlayerScore.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShowPlayerScore.Location = new System.Drawing.Point(32, 170);
            this.lblShowPlayerScore.Name = "lblShowPlayerScore";
            this.lblShowPlayerScore.Size = new System.Drawing.Size(230, 55);
            this.lblShowPlayerScore.TabIndex = 11;
            this.lblShowPlayerScore.Text = "...";
            // 
            // lblShowDealerScore
            // 
            this.lblShowDealerScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShowDealerScore.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShowDealerScore.Location = new System.Drawing.Point(507, 166);
            this.lblShowDealerScore.Name = "lblShowDealerScore";
            this.lblShowDealerScore.Size = new System.Drawing.Size(230, 55);
            this.lblShowDealerScore.TabIndex = 10;
            this.lblShowDealerScore.Text = "...";
            // 
            // lblShowWinner
            // 
            this.lblShowWinner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShowWinner.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShowWinner.Location = new System.Drawing.Point(267, 111);
            this.lblShowWinner.Name = "lblShowWinner";
            this.lblShowWinner.Size = new System.Drawing.Size(232, 231);
            this.lblShowWinner.TabIndex = 12;
            this.lblShowWinner.Text = "winner";
            this.lblShowWinner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPlayAgain
            // 
            this.btnPlayAgain.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlayAgain.Location = new System.Drawing.Point(294, 500);
            this.btnPlayAgain.Name = "btnPlayAgain";
            this.btnPlayAgain.Size = new System.Drawing.Size(175, 47);
            this.btnPlayAgain.TabIndex = 13;
            this.btnPlayAgain.Text = "Play Again?";
            this.btnPlayAgain.UseVisualStyleBackColor = true;
            this.btnPlayAgain.Click += new System.EventHandler(this.btnPlayAgain_Click);
            // 
            // Blackjack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(772, 749);
            this.Controls.Add(this.btnPlayAgain);
            this.Controls.Add(this.lblShowWinner);
            this.Controls.Add(this.lblShowPlayerScore);
            this.Controls.Add(this.lblShowDealerScore);
            this.Controls.Add(this.lblDealerScore);
            this.Controls.Add(this.lblPlayerScore);
            this.Controls.Add(this.lblShowDealerCards);
            this.Controls.Add(this.lblShowPlayerCards);
            this.Controls.Add(this.lblDealerHand);
            this.Controls.Add(this.lblPlayerHand);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnEndGame);
            this.Controls.Add(this.btnStay);
            this.Controls.Add(this.btnHit);
            this.Name = "Blackjack";
            this.Text = "Blackjack";
            this.Load += new System.EventHandler(this.Blackjack_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnHit;
        private System.Windows.Forms.Button btnStay;
        private System.Windows.Forms.Button btnEndGame;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblPlayerHand;
        private System.Windows.Forms.Label lblDealerHand;
        private System.Windows.Forms.Label lblShowPlayerCards;
        private System.Windows.Forms.Label lblShowDealerCards;
        private System.Windows.Forms.Label lblPlayerScore;
        private System.Windows.Forms.Label lblDealerScore;
        private System.Windows.Forms.Label lblShowPlayerScore;
        private System.Windows.Forms.Label lblShowDealerScore;
        private System.Windows.Forms.Label lblShowWinner;
        private System.Windows.Forms.Button btnPlayAgain;
    }
}

