﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kieffer.Blackjack
{
    public partial class Blackjack : Form
    {
        //attribute
        private bool showClosedCard = true;
        private Boot _boot = new Boot();
        private UserInputsAndOutputs _inOut = new UserInputsAndOutputs();
        private Dealer _dealer = new Dealer();
        private Player _player = new Player();

        //Felipe helped me with this

        public Blackjack()
        {
            InitializeComponent();
        }

        private void Blackjack_Load(object sender, EventArgs e)
        {
            lblShowPlayerScore.Text = "";
            lblShowDealerScore.Text = "";

            lblShowWinner.Text = "";

            btnHit.Visible = true;
            btnStay.Visible = true;
            btnPlayAgain.Visible = false;

            NewGameDeal();
        }

        private void NewGameDeal()
        {
            //deal hand to player and dealer
            //        one closed to each then one open to each

            _player.SetClosedCards(ObtainOneCard());
            _dealer.SetClosedCards(ObtainOneCard());
            _player.AddOneCardToOpenCards(ObtainOneCard());
            _dealer.AddOneCardToOpenCards(ObtainOneCard());

            DisplayPlayerHand();
            DisplayDealerHand();
        }

        private String ObtainOneCard()
        {
            return _boot.DealOneCard();
        }

        public void DisplayPlayerHand()
        {
            String[] open = _player.GetOpenCards();
            String closed;

            if (showClosedCard)
            {
                closed = "Closed Card";
            }
            else
            {
                closed = _player.GetClosedCard();
            }

            lblShowPlayerCards.Visible = true;

            lblShowPlayerCards.Text = "[" + closed + "]\n\n";

            for (int n = 0; n < open.Length; n++)
                lblShowPlayerCards.Text += open[n] + "\n";
        }

        public void DisplayPlayerScore()
        {
            Score scr = new Score();

            lblShowPlayerScore.Visible = true;

            lblShowPlayerScore.Text = (scr.CalcPlayerScoreIncludingAce(_player.GetOpenCards(), _player.GetClosedCard()).ToString());
        }

        public void DisplayDealerHand()
        {
            String[] open = _dealer.GetOpenCards();
            String closed;

            if (showClosedCard)
            {
                closed = "Closed Card";
            }
            else
            {
                closed = _dealer.GetClosedCard();
            }

            lblShowDealerCards.Visible = true;

            lblShowDealerCards.Text = "[" + closed + "]\n\n";

            for (int n = 0; n < open.Length; n++)
                lblShowDealerCards.Text += open[n] + "\n";
        }

        public void DisplayDealerScore()
        {
            Score scr = new Score();

            lblShowDealerScore.Visible = true;

            lblShowDealerScore.Text = (scr.CalcDealerScoreIncludingAce(_dealer.GetOpenCards(), _dealer.GetClosedCard()).ToString());
        }

        public void HitOrStayPlayer()
        {
            Score scr = new Score();
            int playerScore = 0;

            if (_player.GetOpenCards()[9] != null)
            {
                DisplayPlayerScore();
                HitOrStayDealer();
            }

            DisplayPlayerHand();

            playerScore = scr.CalcPlayerScoreIncludingAce(_player.GetOpenCards(), _player.GetClosedCard());

            if (playerScore == 21)
            {
                int dealerScore = scr.CalcDealerScoreIncludingAce(_dealer.GetOpenCards(), _dealer.GetClosedCard());
                WinOrLose(playerScore, dealerScore);
                return;
            }

            if (playerScore > 21)
            {
                WinOrLose(playerScore, 0);
                return;
            }

            _player.AddOneCardToOpenCards(ObtainOneCard());

            btnHit.Enabled = true;
            btnStay.Enabled = true;
        }

        public void HitOrStayDealer()
        {
            Score scr = new Score();
            int dealerScore = 0;
            int playerScore = 0;

            DisplayDealerHand();
            DisplayDealerScore();

            dealerScore = scr.CalcDealerScoreIncludingAce(_dealer.GetOpenCards(), _dealer.GetClosedCard());
            
            if (dealerScore == 21)
            {
                playerScore = scr.CalcDealerScoreIncludingAce(_dealer.GetOpenCards(), _dealer.GetClosedCard());
                WinOrLose(playerScore, dealerScore);
                return;
            }

            if (dealerScore > 21)
            {
                WinOrLose(dealerScore, 0);
                return;
            }

            if (_dealer.DealerRules())
            {
                _dealer.AddOneCardToOpenCards(ObtainOneCard());
                HitOrStayDealer();
            }
            else //dealer hits
            {
                WinOrLose(playerScore, dealerScore); //dealer stays
            }

            HitOrStayDealer();
        }

        public void WinOrLose(int playerScore, int dealerScore)
        {
            if (playerScore > 21)
            {
                //show playerHand
                //dealer wins

                lblShowWinner.Text = "Dealer Wins! \nYou went over 21";

                showClosedCard = false;
                DisplayPlayerHand();
                DisplayDealerHand();

                DisplayPlayerScore();
                DisplayDealerScore();

                ShowPlayAgainButton();

                return;
            }

            if (dealerScore > 21)
            {
                //show both hands
                //player wins

                lblShowWinner.Text = "You Win! \nThe dealer went over 21!";

                ShowPlayAgainButton();

                return;
            }

            if (dealerScore == 21 && playerScore == 21)
            {
                //show both hands
                //push game

                lblShowWinner.Text = "Push! \nYou and the Dealer both have a Blackjack!";

                ShowPlayAgainButton();

                return;
            }

            if (playerScore == 21)
            {
                //show playerHand
                //player wins

                lblShowWinner.Text = "You Win! \nYou have a Blackjack!";

                ShowPlayAgainButton();

                return;
            }

            if (dealerScore == 21)
            {
                //show both hands
                //dealer wins

                lblShowWinner.Text = "Dealer Wins! \nThe Dealer has a Blackjack!";

                ShowPlayAgainButton();

                return;
            }

            if (playerScore == dealerScore)
            {
                //show both hands
                //push game

                lblShowWinner.Text = "Push! \nYou and the Dealer are tied!";

                ShowPlayAgainButton();

                return;
            }

            //if player total is greater than dealer total, player wins
            //if dealer total is greater than player total, dealer wins
            // if both have the same total declare a push
        }

        public void PlayAgain()
        {
            _player = new Player();
            _dealer = new Dealer();

            lblPlayerScore.Text = "";
            lblDealerScore.Text = "";

            lblShowWinner.Text = "";

            showClosedCard = true;

            NewGameDeal();
        }

        private void btnHit_Click(object sender, EventArgs e)
        {
            HitOrStayPlayer();
        }

        private void btnStay_Click(object sender, EventArgs e)
        {
            DisplayPlayerScore();
            DisplayDealerScore();

            HitOrStayDealer();

            DisplayPlayerHand();
            DisplayDealerHand();

            WinOrLose(
                int.Parse(lblShowPlayerScore.Text), 
                int.Parse(lblShowDealerScore.Text));

            ShowPlayAgainButton();
        }

        private void ShowHitAndStayButtons()
        {
            btnHit.Visible = true;
            btnStay.Visible = true;
            btnPlayAgain.Visible = false;
        }

        private void btnEndGame_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnPlayAgain_Click(object sender, EventArgs e)
        {
            PlayAgain();

            ShowHitAndStayButtons();
        }

        private void ShowPlayAgainButton()
        {
            btnHit.Visible = false;
            btnStay.Visible = false;
            btnPlayAgain.Visible = true;
        }
    }
}
