﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Kieffer.Blackjack
{
    public class Boot
    {
        //attributes
        private int numberOfDecks = 4;
        private int cardToDeal = -1;
        private String[] theCards = null;

        public Boot()
        {
            InitializeTheCards();
        }

        private void InitializeTheCards()
        {
            //create and obtain a deck of cards
            MyDeckOfCards theDeck = new MyDeckOfCards();
            String[] cards = theDeck.GetTheDeck();

            //instantiate the cards so it can contain the number of decks
            theCards = new String[cards.Length * numberOfDecks];

            //copy the deck into the cards four times
            for (int n = 0, p = 0; n < theCards.Length; n++, p++)
            {
                // gets 12
                // if it gets to 13, it starts over
                if (p == cards.Length)
                    p = 0;

                theCards[n] = cards[p];
            }

            Shuffle sfl = new Shuffle(theCards);
            theCards = sfl.GetTheShuffledDeckOfCards();

            cardToDeal = theCards.Length - 1;
        }

        public void ReshuffleTheBoot()
        {
            //mix the deck
            Shuffle mixTheCards = new Shuffle(theCards);

            theCards = mixTheCards.GetTheShuffledDeckOfCards();

            cardToDeal = theCards.Length;
        }

        public String DealOneCard(bool newGame)
        {
            //if the cards are less than 53, it will reshuffle
            if (newGame && cardToDeal < 53)
            {
                ReshuffleTheBoot();
                //after shuffle cardToDeal is 208, which is greater than last element number which is why there is the -1
                cardToDeal = theCards.Length;
            }

            return DealOneCard();
        }

        public String DealOneCard()
        {
            //deal the next card in the array 
            cardToDeal--;

            return theCards[cardToDeal];
        }
        //made referencing code in class
    }
}
