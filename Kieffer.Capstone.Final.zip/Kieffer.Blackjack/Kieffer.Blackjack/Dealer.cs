﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kieffer.Blackjack
{
    public class Dealer : Player
    {
        public Dealer() { }

        public bool DealerRules()
        {
            //determine the dealer's hand total value

            //if the value is < 16, hit
            // else, stay

            //copy all the closed cards

            Score theNumericValue = new Score();
            String[] theCards = new String[openCards.Length + 1];
            int handValue;

            theCards[0] = closedCard;

            //create a loop
            //+1 because we are starting at one
            for (int n = 1; n < openCards.Length + 1; n++)
                theCards[n] = openCards[n - 1];
            //put dealer hand, both closed card and all open cards, in theCards

            handValue = theNumericValue.CalcDealerScoreIncludingAce(theCards, closedCard);

            if (handValue < 17)
                return false;   //hit = false, don’t take a card
            else
                return true;	//stay = true, take a card
        }
    }
}
