﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kieffer.Blackjack
{
    public class MyDeckOfCards
    {
        private String[] theDeck = null;
        private int numberOfCardsInDeck = -1;

        public MyDeckOfCards()
        {
            CreateDeckArray();
            InitializeDeck();
            AddTheCardNumbersToTheDeckString();
            AddTheFaceNameToDeckString();
            AddAceToTheDeckString();
            AddSuitesToTheDeckString();
        }

        public void CreateDeckArray()
        {
            theDeck = new String[52];
        }

        public void InitializeDeck()
        {
            for (int n = 0; n < theDeck.Length; n++)
                theDeck[n] = (n + 1).ToString();
        }

        public bool SetNumberOfCardsInDeck(String s)
        {
            if (s == null || s.Length == 0)
                return false;

            if (CanBePositiveInt(s))
            {
                numberOfCardsInDeck = int.Parse(s);
                return true;
            }
            return false;
        }

        public String[] GetTheDeck()
        {
            return theDeck;
        }

        public void AddTheCardNumbersToTheDeckString()
        {
            //append the card number to each card that will end up as a number 

            int theCard;

            for (int n = 0; n < theDeck.Length; n++)
            {
                theCard = int.Parse(theDeck[n]) % 13;

                theDeck[n] = theCard.ToString();
            }
        }

        public void AddTheFaceNameToDeckString()
        {
            //append face names to each card

            for (int n = 0; n < theDeck.Length; n++)
            {
                if (theDeck[n].Equals("11"))
                {
                    theDeck[n] = "jack";
                }

                else if (theDeck[n].Equals("12"))
                {
                    theDeck[n] = "queen";
                }

                else if (theDeck[n].Equals("0"))
                {
                    theDeck[n] = "king";
                }
            }
        }

        public void AddAceToTheDeckString()
        {
            //append 'ace' to each card that will end up as an ace

            for (int n = 0; n < theDeck.Length; n++)
            {
                if (theDeck[n].Equals("1"))
                {
                    theDeck[n] = "ace";
                }
            }
        }

        public void AddSuitesToTheDeckString()
        {
            //append suite to each card number
            //1-13 are clubs
            //14-26 are diamonds 
            //27-39 are hearts
            //40-52 are spades

            for (int n = 0; n < theDeck.Length; n++)
            {
                if (n / 13 == 0)
                {
                    theDeck[n] += " of clubs";
                }
                else if (n / 13 == 1)
                {
                    theDeck[n] += " of diamonds";
                }
                else if (n / 13 == 2)
                {
                    theDeck[n] += " of hearts";
                }
                else if (n / 13 == 3)
                {
                    theDeck[n] += " of spades";
                }
            }
        }

        private bool CanBePositiveInt(String s)
        {
            try
            {
                if (Convert.ToInt32(s) > 0)
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //public String[] returnTheDeck(String[] theDeck)
        //{
        //    for (int n = 0; n < theDeck.Length; n++)
        //    {
        //        Console.Write(theDeck[n] + " ");
        //
        //        if ((n + 1) % 13 == 0)
        //            Console.WriteLine();
        //    }

        //    return theDeck;
        //}

    }

}

