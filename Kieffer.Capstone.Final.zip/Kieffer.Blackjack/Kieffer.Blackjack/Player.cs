﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kieffer.Blackjack
{
    public class Player
    {
        //attributes 
        protected String closedCard = null;
        //if the player has 11 cards, and has not gone over, player has 21 and player wins
        protected String[] openCards = new String[10];
        protected int numOpenCards = 0;

        public Player() { }

        public bool AddOneCardToOpenCards(String newCard)
        {
            if (numOpenCards >= openCards.Length)
                return false;
            //if number of openCards > 10, cannot add another card

            openCards[numOpenCards] = newCard;

            //increment numOpenCards
            numOpenCards++;

            return true;
        }

        public String[] GetOpenCards()
        {
            return openCards;
        }

        public bool SetClosedCards(String s)
        {
            if (s == null || s.Length == 0)
                return false;

            closedCard = s;
            return true;
        }

        public String GetClosedCard()
        {
            return closedCard;
        }
    }
    //made referencing code in class
}
