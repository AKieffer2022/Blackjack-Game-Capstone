﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kieffer.Blackjack
{
    public class Score
    {
        public Score() { }

        private int CalcScoreWithoutAce(String[] theCards)
        {
            //calculate the scaore without ace
            //convert number card 
            //convert picture card other than ace

            int handValue = 0;

            for (int n = 0; n < theCards.Length; n++)
            {
                if (theCards[n] != null)
                {
                    if (theCards[n].Length < 3) //number card
                        handValue += Convert.ToInt16(theCards[n]);

                    else if (theCards[n].Length > 3) //picture card - not ace
                        handValue += 10;
                }
            }
            return handValue;
        }

        public int CalcPlayerScoreIncludingAce(String[] theCards, String closedCard)
        {
            theCards = FullPlayerHand(theCards, closedCard);

            int handValue = 0;
            theCards = RemoveSuit(theCards);

            handValue = CalcScoreWithoutAce(theCards);

            for (int n = 0; n < theCards.Length; n++)
            {
                //the card must be an ace
                if (theCards[n] == null)
                    continue;

                theCards[n] = theCards[n].ToLower();

                if (theCards[n].Equals("ace"))
                {
                    if (handValue + 11 < 22)
                    {
                        handValue += 11;
                    }
                    else
                    {
                        handValue++;
                    }
                }
            }
            return handValue;
        }

        private String[] FullPlayerHand(String[] theCards, string closedCard)
        {
            //creates one string for the entire deck
            String[] temp = new String[theCards.Length + 1];

            temp[0] = closedCard;

            for (int n = 1; n < temp.Length; n++)
                temp[n] = theCards[n - 1];

            return temp;
        }

        public int CalcDealerScoreIncludingAce(String[] theCards, String closedCard)
        {
            theCards = FullPlayerHand(theCards, closedCard);

            int handValue = 0;
            theCards = RemoveSuit(theCards);

            handValue = CalcScoreWithoutAce(theCards);

            for (int n = 0; n < theCards.Length; n++)
            {
                if (theCards[n] == null)
                    continue;

                theCards[n] = theCards[n].ToLower();
                if (theCards[n].Equals("ace"))
                    handValue += 11;
            }
            return handValue;
        }

        private String[] RemoveSuit(String[] theCards)
        {
            for (int n = 0; n < theCards.Length; n++)
            {
                if (theCards[n] == null)
                    continue;

                //get rid of the suit
                theCards[n] = theCards[n].Substring(0, theCards[n].IndexOf(" "));
                theCards[n] = theCards[n].Trim(); //get rid of extra trailing blanks
            }
            return theCards;
        }
        //had help from Felipe
    }
}
