﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kieffer.Blackjack
{
    public class Shuffle
    {
        private String[] theShuffledDeckOfCards = null;

        public Shuffle (String[] theDeck)
        {
            theShuffledDeckOfCards = ShuffleDeck(theDeck);
        }

        public String[] GetTheShuffledDeckOfCards()
        {
            return theShuffledDeckOfCards;
        }

        public string[] ShuffleDeck(string[] theDeck)
        {
            string[] theShuffledDeckOfCards = new string[theDeck.Length];
            Random random = new Random();

            for (int n = 0; n < theDeck.Length; n++)
            {
                int index;
                do
                {
                    index = random.Next(0, theDeck.Length);
                }
                while (theDeck[index] == "-1");

                theShuffledDeckOfCards[n] = theDeck[index];

                theDeck[index] = "-1";

                //Console.Write(shuffleTheCards[n] + "\n");
                //if (n % 13 == 0 && n > 0)
                //    Console.WriteLine();

                //Felipe helped me with this
            }

            return theShuffledDeckOfCards;
        }
    }
}

