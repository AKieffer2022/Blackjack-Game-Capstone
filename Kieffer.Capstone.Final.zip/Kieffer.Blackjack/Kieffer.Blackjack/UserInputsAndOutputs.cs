﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kieffer.Blackjack
{
    public class UserInputsAndOutputs
    {
        public UserInputsAndOutputs() { }

        public void DisplayMessageToUser(String message)
        {
            Console.WriteLine(message);
        }

        public String GetDataFromUser(String message)
        {
            Console.WriteLine(message);
            return Console.ReadLine();
        }
    }
}
